#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"
struct ShapeDef
{
	float density;
	float restitution;
	float friction;
	bool  sensor;
	int   catogoryBits;
	int   maskBits;
	int   groupIndex;
};

static inline b2FixtureDef ShapeParams2FixtureDef(ShapeDef def)
{
    b2FixtureDef fd;
    fd.friction = def.friction;
    fd.density = def.density;
    fd.restitution = def.restitution;
    fd.isSensor = def.sensor;
    b2Filter f;
    f.categoryBits = def.catogoryBits;
    f.maskBits = def.maskBits;
    f.groupIndex = def.groupIndex;
    fd.filter = f;
    return fd;
}

extern "C"
{
 
    EXTERN_DLL_EXPORT IntPtr AddPolygonShape( IntPtr b, b2Vec2 v[], int len, ShapeDef def )
    {
        if( b == NULL )
            return NULL;
        
        b2Body *body = (b2Body*)b;
        b2PolygonShape shape;
        shape.Set(v,len);
        b2FixtureDef fd = ShapeParams2FixtureDef(def);
        fd.shape = &shape;
        return body->CreateFixture(&fd);
    }
    
    EXTERN_DLL_EXPORT IntPtr  AddBoxShape( IntPtr b, float w, float h, b2Vec2 center, float angle, ShapeDef def)
    {
        if( b == NULL )
            return NULL;
        
        b2Body *body = (b2Body*)b;
        b2PolygonShape shape;
        shape.SetAsBox(w, h, center, angle);
        b2FixtureDef fd = ShapeParams2FixtureDef(def);
        fd.shape = &shape;
        return body->CreateFixture(&fd);
    }
    
    EXTERN_DLL_EXPORT IntPtr  AddCircleShape( IntPtr b, float r, ShapeDef def )
    {
        if( b == NULL )
            return NULL;
        
        b2Body *body = (b2Body*)b;
        b2CircleShape shape;
        shape.m_radius = r;
        b2FixtureDef fd = ShapeParams2FixtureDef(def);
        fd.shape = &shape;
        return body->CreateFixture(&fd);
    }
    
    EXTERN_DLL_EXPORT IntPtr  AddEdgeShape( IntPtr b, b2Vec2 p0, b2Vec2 p1, ShapeDef def)
    {
        if( b == NULL )
            return NULL;
        
        b2Body *body = (b2Body*)b;
        b2EdgeShape shape;
        shape.Set(p0, p1);
        b2FixtureDef fd = ShapeParams2FixtureDef(def);
        fd.shape = &shape;
        return body->CreateFixture(&fd);
    }
    
    EXTERN_DLL_EXPORT void DestroyShape( IntPtr b, IntPtr f )
    {
        b2Body *body = (b2Body*)b;
        b2Fixture *fixture = (b2Fixture*)f;
        body->DestroyFixture(fixture);
    }

    EXTERN_DLL_EXPORT void GetPosition( IntPtr b, Vector2* pos)
    {
        if( b == NULL )
            return;
            
        b2Body *body = (b2Body*)b;
        *pos = body->GetPosition();
    }
    
    EXTERN_DLL_EXPORT float GetAngle( IntPtr b )
    {
        if( b == NULL )
            return 0;
        
        b2Body *body = (b2Body*)b;
        return body->GetAngle();
    }

    EXTERN_DLL_EXPORT void SetTransform( IntPtr b, Vector2 pos, float angle )
    {
        if( b == NULL )
            return;
        b2Body *body = (b2Body*)b;
        
        body->SetTransform(pos,angle);
    }
    
	EXTERN_DLL_EXPORT void GetWorldCenter( IntPtr b, Vector2* worldCenter)
    {
        if( b == NULL )
            return;
        b2Body *body = (b2Body*)b;
        *worldCenter = body->GetWorldCenter();
    }
    
	EXTERN_DLL_EXPORT void GetLocalCenter( IntPtr b, Vector2* localCenter)
    {
        if( b == NULL )
            return;
        b2Body *body = (b2Body*)b;
        *localCenter = body->GetLocalCenter();
    }
    
    EXTERN_DLL_EXPORT void SetLinearVelocity( IntPtr b, Vector2 v)
    {
        if( b == NULL )
            return;
        b2Body *body = (b2Body*)b;
        
        body->SetLinearVelocity(v);
    }

	EXTERN_DLL_EXPORT void GetLinearVelocity( IntPtr b, Vector2* v )
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        *v = body->GetLinearVelocity();
    }
    
	EXTERN_DLL_EXPORT void SetAngularVelocity( IntPtr b, float omega)
    {
        if( b == NULL )
            return ;
        
        b2Body *body = (b2Body*)b;
        body->SetAngularVelocity( omega );
    }

	EXTERN_DLL_EXPORT float GetAngularVelocity( IntPtr b )
    {
        if( b == NULL )
            return 0;
        
        b2Body *body = (b2Body*)b;
        return body->GetAngularVelocity();
    }

    EXTERN_DLL_EXPORT void ApplyForce( IntPtr b, b2Vec2 force, b2Vec2 point )
    {
        if( b == NULL )
            return;
            
        b2Body *body = (b2Body*)b;
        body->ApplyForce(force,point);
    }

    EXTERN_DLL_EXPORT void ApplyForceToCenter( IntPtr b, b2Vec2 force )
    {
        if( b == NULL )
            return;
            
        b2Body *body = (b2Body*)b;
        body->ApplyForceToCenter(force);
    }
        
    EXTERN_DLL_EXPORT void ApplyTorque( IntPtr b, float torque)
    {
        if( b == NULL )
            return;
            
        b2Body *body = (b2Body*)b;
        body->ApplyTorque(torque);
    }

    EXTERN_DLL_EXPORT void ApplyLinearImpulse( IntPtr b, b2Vec2 impulse, b2Vec2 point)
    {
        if( b == NULL )
            return;
            
        b2Body *body = (b2Body*)b;
        body->ApplyLinearImpulse( impulse, point );
    }

    EXTERN_DLL_EXPORT void ApplyAngularImpulse( IntPtr b, float impulse)
    {
        if( b == NULL )
            return;
            
        b2Body *body = (b2Body*)b;
        body->ApplyAngularImpulse(impulse);
    }
    
	EXTERN_DLL_EXPORT float GetMass( IntPtr b )
    {
        if( b == NULL )
            return 0;
        
        b2Body *body = (b2Body*)b;
        return body->GetMass();
        
    }
    
	EXTERN_DLL_EXPORT float GetInertia( IntPtr b )
    {
        if( b == NULL )
            return 0;
        
        b2Body *body = (b2Body*)b;
        return body->GetInertia();
       
    }
    
    EXTERN_DLL_EXPORT void ResetMassData( IntPtr b )
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        return body->ResetMassData();
    }
    
    
	EXTERN_DLL_EXPORT void GetWorldPoint( IntPtr b, Vector2 localPoint, Vector2 *worldPoint)
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        *worldPoint = body->GetWorldPoint( localPoint );
    }
    
	EXTERN_DLL_EXPORT void GetWorldVector( IntPtr b, Vector2 localVector, Vector2 *worldVector)
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        *worldVector = body->GetWorldVector( localVector );
    }
    
  	EXTERN_DLL_EXPORT void GetLocalPoint( IntPtr b, Vector2 worldPoint, Vector2 *localPoint)
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        *localPoint = body->GetLocalPoint( worldPoint );
    }
    
	EXTERN_DLL_EXPORT void GetLocalVector( IntPtr b, Vector2 worldVector, Vector2 *localVector)
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        *localVector = body->GetLocalVector( worldVector );
    }
    
    EXTERN_DLL_EXPORT void GetLinearVelocityFromWorldPoint( IntPtr b, Vector2 worldPoint, Vector2* linearVelocity )
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        *linearVelocity = body->GetLinearVelocityFromWorldPoint( worldPoint );
    }

	EXTERN_DLL_EXPORT void GetLinearVelocityFromLocalPoint( IntPtr b , const b2Vec2& localPoint, Vector2* linearVelocity )
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        *linearVelocity = body->GetLinearVelocityFromLocalPoint( localPoint );
    }

	EXTERN_DLL_EXPORT float32 GetLinearDamping( IntPtr b )
    {
        if( b == NULL )
            return 0;
        
        b2Body *body = (b2Body*)b;
        return body->GetLinearDamping();
    }

	EXTERN_DLL_EXPORT void SetLinearDamping( IntPtr b , float32 linearDamping)
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        body->SetLinearDamping( linearDamping );
    }

	EXTERN_DLL_EXPORT float32 GetAngularDamping( IntPtr b )
    {
        if( b == NULL )
            return 0;
        
        b2Body *body = (b2Body*)b;
        return body->GetAngularDamping( );
    }

	EXTERN_DLL_EXPORT void SetAngularDamping( IntPtr b , float32 angularDamping)
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        body->SetAngularDamping( angularDamping );
    }

	EXTERN_DLL_EXPORT float32 GetGravityScale( IntPtr b )
    {
        if( b == NULL )
            return 0;
        
        b2Body *body = (b2Body*)b;
        return body->GetGravityScale( );
    }

	EXTERN_DLL_EXPORT void SetGravityScale( IntPtr b , float32 scale)
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        body->SetGravityScale( scale );
    }

	EXTERN_DLL_EXPORT void SetType( IntPtr b , int type)
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        body->SetType( (b2BodyType)type );
    }

	EXTERN_DLL_EXPORT int GetType( IntPtr b )
    {
        if( b == NULL )
            return 0;
        
        b2Body *body = (b2Body*)b;
        return body->GetType();
    }

	EXTERN_DLL_EXPORT void SetBullet( IntPtr b , bool flag)
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        body->SetBullet( flag );
    }

	EXTERN_DLL_EXPORT bool IsBullet( IntPtr b )
    {
        if( b == NULL )
            return false;
        
        b2Body *body = (b2Body*)b;
        return body->IsBullet( );
    }

	EXTERN_DLL_EXPORT void SetSleepingAllowed( IntPtr b , bool flag)
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        body->SetSleepingAllowed( flag );
    }

	EXTERN_DLL_EXPORT bool IsSleepingAllowed( IntPtr b )
    {
        if( b == NULL )
            return false;
        
        b2Body *body = (b2Body*)b;
        return body->IsSleepingAllowed( );
    }

	EXTERN_DLL_EXPORT void SetAwake( IntPtr b , bool flag)
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        body->SetAwake( flag );
    }

	EXTERN_DLL_EXPORT bool IsAwake( IntPtr b )
    {
        if( b == NULL )
            return false;
        
        b2Body *body = (b2Body*)b;
        return body->IsAwake();
    }

	EXTERN_DLL_EXPORT void SetActive( IntPtr b , bool flag)
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        body->SetActive( flag );
    }

	EXTERN_DLL_EXPORT bool IsActive( IntPtr b )
    {
        if( b == NULL )
            return false;
        
        b2Body *body = (b2Body*)b;
        return body->IsActive( );
    }

	EXTERN_DLL_EXPORT void SetFixedRotation( IntPtr b , bool flag)
    {
        if( b == NULL )
            return;
        
        b2Body *body = (b2Body*)b;
        body->SetFixedRotation( flag );
    }

	EXTERN_DLL_EXPORT bool IsFixedRotation( IntPtr b )
    {
        if( b == NULL )
            return false;
        
        b2Body *body = (b2Body*)b;
        return body->IsFixedRotation();
    }
    
    EXTERN_DLL_EXPORT IntPtr GetWorld( IntPtr b )
    {
        if( b == NULL )
            return false;
        
        b2Body *body = (b2Body*)b;
        return body->GetWorld();
    }
}