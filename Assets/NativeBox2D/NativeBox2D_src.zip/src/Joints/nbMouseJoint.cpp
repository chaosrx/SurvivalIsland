#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"

extern "C"
{
    //MouseJoint
    EXTERN_DLL_EXPORT void MouseJointSetTarget( IntPtr j, Vector2 target)
    {
        if( j == NULL )
            return;
            
        b2MouseJoint *joint = (b2MouseJoint*)j;
        joint->SetTarget( target );
    }
    
    EXTERN_DLL_EXPORT void MouseJointGetTarget( IntPtr j, Vector2* target )
    {
        if( j == NULL )
            return;
        
        b2MouseJoint *joint = (b2MouseJoint*)j;
        *target = joint->GetTarget();
    }
 
	EXTERN_DLL_EXPORT void MouseJointSetMaxForce( IntPtr j , float32 force)
    {
        if( j == NULL )
            return;
        
        b2MouseJoint *joint = (b2MouseJoint*)j;
        joint->SetMaxForce(force);
    }
    
	EXTERN_DLL_EXPORT float32 MouseJointGetMaxForce( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2MouseJoint *joint = (b2MouseJoint*)j;
        return joint->GetMaxForce();
       
    }
    
	EXTERN_DLL_EXPORT void MouseJointSetFrequency( IntPtr j , float32 hz)
    {
        if( j == NULL )
            return;
        
        b2MouseJoint *joint = (b2MouseJoint*)j;
        joint->SetFrequency(hz);
    }
    
	EXTERN_DLL_EXPORT float32 MouseJointGetFrequency( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2MouseJoint *joint = (b2MouseJoint*)j;
        return joint->GetFrequency();
        
    }
    
	EXTERN_DLL_EXPORT void MouseJointSetDampingRatio( IntPtr j, float32 ratio)
    {
        if( j == NULL )
            return;
        
        b2MouseJoint *joint = (b2MouseJoint*)j;
        joint->SetDampingRatio(ratio);
    }
    
	EXTERN_DLL_EXPORT float32 MouseJointGetDampingRatio( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2MouseJoint *joint = (b2MouseJoint*)j;
        return joint->GetDampingRatio();
    }
}