#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"

extern "C"
{
    //WeldJoint    
    EXTERN_DLL_EXPORT void WeldJointGetLocalAnchorA( IntPtr j, Vector2 * localAnchorA )
    {
        if( j == NULL )
            return;
        
        b2WeldJoint *joint = (b2WeldJoint*)j;
        *localAnchorA = joint->GetLocalAnchorA();
    }
    
    EXTERN_DLL_EXPORT void WeldJointGetLocalAnchorB( IntPtr j, Vector2 * localAnchorB )
    {
        if( j == NULL )
            return;
        
        b2WeldJoint *joint = (b2WeldJoint*)j;
        *localAnchorB = joint->GetLocalAnchorB();
    }
 
    EXTERN_DLL_EXPORT float WeldJointGetReferenceAngle( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2WeldJoint *joint = (b2WeldJoint*)j;
        return joint->GetReferenceAngle();
    }
 
    EXTERN_DLL_EXPORT void WeldJointSetFrequency( IntPtr j, float hz )
    {
        if( j == NULL )
            return;
        
        b2WeldJoint *joint = (b2WeldJoint*)j;
        joint->SetFrequency(hz);
    }
    
    EXTERN_DLL_EXPORT float WeldJointGetFrequency( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2WeldJoint *joint = (b2WeldJoint*)j;
        return joint->GetFrequency();
    }
    
    EXTERN_DLL_EXPORT void WeldJointSetDampingRatio( IntPtr j, float ratio )
    {
        if( j == NULL )
            return;
        
        b2WeldJoint *joint = (b2WeldJoint*)j;
        joint->SetDampingRatio(ratio);
    }
    
    EXTERN_DLL_EXPORT float WeldJointGetDampingRatio( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2WeldJoint *joint = (b2WeldJoint*)j;
        return joint->GetDampingRatio();
    }
}