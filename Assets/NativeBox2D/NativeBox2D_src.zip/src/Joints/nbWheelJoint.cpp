#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"

extern "C"
{
    //WheelJoint    
    EXTERN_DLL_EXPORT void WheelJointGetLocalAnchorA( IntPtr j, Vector2 * localAnchorA )
    {
        if( j == NULL )
            return;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        *localAnchorA = joint->GetLocalAnchorA();
    }
    
    EXTERN_DLL_EXPORT void WheelJointGetLocalAnchorB( IntPtr j, Vector2 * localAnchorB )
    {
        if( j == NULL )
            return;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        *localAnchorB = joint->GetLocalAnchorB();
    }
    
    EXTERN_DLL_EXPORT void WheelJointGetLocalAxisA( IntPtr j, Vector2 * localAxisA )
    {
        if( j == NULL )
            return;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        *localAxisA = joint->GetLocalAxisA();
    }
    
    EXTERN_DLL_EXPORT float WheelJointGetJointTranslation( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        return joint->GetJointTranslation();
    }
    
    EXTERN_DLL_EXPORT float WheelJointGetJointSpeed( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        return joint->GetJointSpeed();
    }
    
    EXTERN_DLL_EXPORT bool WheelJointIsMotorEnabled( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        return joint->IsMotorEnabled();
    }
    
    EXTERN_DLL_EXPORT void WheelJointEnableMotor( IntPtr j , bool flag )
    {
        if( j == NULL )
            return;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        joint->EnableMotor(flag);
    }
    
    EXTERN_DLL_EXPORT void WheelJointSetMotorSpeed( IntPtr j, float speed )
    {
        if( j == NULL )
            return;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        joint->SetMotorSpeed(speed);
    }
    
    EXTERN_DLL_EXPORT float WheelJointGetMotorSpeed( IntPtr j )
    {
        if( j == NULL )
            return 0;

        b2WheelJoint *joint = (b2WheelJoint*)j;
        return joint->GetMotorSpeed();
    }
    
    EXTERN_DLL_EXPORT void WheelJointSetMaxMotorTorque( IntPtr j, float torque )
    {
        if( j == NULL )
            return;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        joint->SetMaxMotorTorque(torque);
    }
    
    EXTERN_DLL_EXPORT float WheelJointGetMaxMotorTorque( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        return joint->GetMaxMotorTorque();
    }
    
    EXTERN_DLL_EXPORT void WheelJointSetSpringFrequencyHz( IntPtr j, float hz )
    {
        if( j == NULL )
            return;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        joint->SetSpringFrequencyHz(hz);
    }
    
    EXTERN_DLL_EXPORT float WheelJointGetSpringFrequencyHz( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        return joint->GetSpringFrequencyHz();
    }
    
    EXTERN_DLL_EXPORT void WheelJointSetSpringDampingRatio( IntPtr j, float ratio )
    {
        if( j == NULL )
            return;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        joint->SetSpringDampingRatio(ratio);
    }
    
    EXTERN_DLL_EXPORT float WheelJointGetSpringDampingRatio( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2WheelJoint *joint = (b2WheelJoint*)j;
        return joint->GetSpringDampingRatio();
    }
}