#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"

extern "C"
{
    //PrismaticJoint    
    EXTERN_DLL_EXPORT void PrismaticJointGetLocalAnchorA( IntPtr j, Vector2 * anchorA )
    {
        if( j == NULL )
            return;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        *anchorA = joint->GetLocalAnchorA();
    }
    
    EXTERN_DLL_EXPORT void PrismaticJointGetLocalAnchorB( IntPtr j, Vector2 * anchorB )
    {
        if( j == NULL )
            return;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        *anchorB = joint->GetLocalAnchorB();
    }
    
    EXTERN_DLL_EXPORT void PrismaticJointGetLocalAxisA( IntPtr j, Vector2 * axisA )
    {
        if( j == NULL )
            return;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        *axisA = joint->GetLocalAxisA();
    }
    
    EXTERN_DLL_EXPORT float PrismaticJointGetReferenceAngle( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        return joint->GetReferenceAngle();
    }
    
    EXTERN_DLL_EXPORT float PrismaticJointGetJointTranslation( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        return joint->GetJointTranslation();
    }
    
    EXTERN_DLL_EXPORT float PrismaticJointGetJointSpeed( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        return joint->GetJointSpeed();
    }
    
    EXTERN_DLL_EXPORT bool PrismaticJointIsLimitEnabled( IntPtr j )
    {
        if( j == NULL )
            return false;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        return joint->IsLimitEnabled();
    }
    
    EXTERN_DLL_EXPORT void PrismaticJointEnableLimit( IntPtr j , bool flag )
    {
        if( j == NULL )
            return;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        joint->EnableLimit(flag);
    }
    
    EXTERN_DLL_EXPORT float PrismaticJointGetLowerLimit( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        return joint->GetLowerLimit();
    }
    
    EXTERN_DLL_EXPORT float PrismaticJointGetUpperLimit( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        return joint->GetUpperLimit();
    }
    
    EXTERN_DLL_EXPORT void PrismaticJointSetLimits( IntPtr j , float lower, float upper )
    {
        if( j == NULL )
            return;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        return joint->SetLimits(lower,upper);
    }
    
    EXTERN_DLL_EXPORT bool PrismaticJointIsMotorEnabled( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        return joint->IsMotorEnabled();
    }
    
    EXTERN_DLL_EXPORT void PrismaticJointEnableMotor( IntPtr j , bool flag )
    {
        if( j == NULL )
            return;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        joint->EnableMotor(flag);
    }
    
    EXTERN_DLL_EXPORT void PrismaticJointSetMotorSpeed( IntPtr j, float speed )
    {
        if( j == NULL )
            return;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        joint->SetMotorSpeed(speed);
    }
    
    EXTERN_DLL_EXPORT float PrismaticJointGetMotorSpeed( IntPtr j )
    {
        if( j == NULL )
            return 0;

        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        return joint->GetMotorSpeed();
    }
    
    EXTERN_DLL_EXPORT void PrismaticJointSetMaxMotorForce( IntPtr j, float force )
    {
        if( j == NULL )
            return;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        joint->SetMaxMotorForce( force );
    }
    
    EXTERN_DLL_EXPORT float PrismaticJointGetMaxMotorForce( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        return joint->GetMaxMotorForce();
    }
    
    EXTERN_DLL_EXPORT float PrismaticJointGetMotorForce( IntPtr j , float32 inv_dt )
    {
        if( j == NULL )
            return 0;
        
        b2PrismaticJoint *joint = (b2PrismaticJoint*)j;
        return joint->GetMotorForce( inv_dt );
    }
}