#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"

extern "C"
{
    //RevoluteJoint    
    EXTERN_DLL_EXPORT void RevoluteJointGetLocalAnchorA( IntPtr j, Vector2 * localAnchorA )
    {
        if( j == NULL )
            return;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        *localAnchorA = joint->GetLocalAnchorA();
    }
    
    EXTERN_DLL_EXPORT void RevoluteJointGetLocalAnchorB( IntPtr j, Vector2 * localAnchorB )
    {
        if( j == NULL )
            return;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        *localAnchorB = joint->GetLocalAnchorB();
    }

    EXTERN_DLL_EXPORT float RevoluteJointGetReferenceAngle( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        return joint->GetReferenceAngle();
    }
    
    EXTERN_DLL_EXPORT float RevoluteJointGetJointAngle( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        return joint->GetJointAngle();
    }
    
    EXTERN_DLL_EXPORT float RevoluteJointGetJointSpeed( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        return joint->GetJointSpeed();
    }
    
    EXTERN_DLL_EXPORT bool RevoluteJointIsLimitEnabled( IntPtr j )
    {
        if( j == NULL )
            return false;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        return joint->IsLimitEnabled();
    }
    
    EXTERN_DLL_EXPORT void RevoluteJointEnableLimit( IntPtr j , bool flag )
    {
        if( j == NULL )
            return;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        joint->EnableLimit(flag);
    }
    
    EXTERN_DLL_EXPORT float RevoluteJointGetLowerLimit( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        return joint->GetLowerLimit();
    }
    
    EXTERN_DLL_EXPORT float RevoluteJointGetUpperLimit( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        return joint->GetUpperLimit();
    }
    
    EXTERN_DLL_EXPORT void RevoluteJointSetLimits( IntPtr j , float lower, float upper )
    {
        if( j == NULL )
            return;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        return joint->SetLimits(lower,upper);
    }
    
    EXTERN_DLL_EXPORT bool RevoluteJointIsMotorEnabled( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        return joint->IsMotorEnabled();
    }
    
    EXTERN_DLL_EXPORT void RevoluteJointEnableMotor( IntPtr j , bool flag )
    {
        if( j == NULL )
            return;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        joint->EnableMotor(flag);
    }
    
    EXTERN_DLL_EXPORT void RevoluteJointSetMotorSpeed( IntPtr j, float speed )
    {
        if( j == NULL )
            return;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        joint->SetMotorSpeed(speed);
    }
    
    EXTERN_DLL_EXPORT float RevoluteJointGetMotorSpeed( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        return joint->GetMotorSpeed();
    }
    
    EXTERN_DLL_EXPORT void RevoluteJointSetMaxMotorTorque( IntPtr j, float torque )
    {
        if( j == NULL )
            return;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        joint->SetMaxMotorTorque( torque );
    }
    
    EXTERN_DLL_EXPORT float RevoluteJointGetMaxMotorTorque( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        return joint->GetMaxMotorTorque();
    }
    
    EXTERN_DLL_EXPORT float RevoluteJointGetMotorTorque( IntPtr j , float32 inv_dt )
    {
        if( j == NULL )
            return 0;
        
        b2RevoluteJoint *joint = (b2RevoluteJoint*)j;
        return joint->GetMotorTorque( inv_dt );
    }
}