#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"

extern "C"
{
    //RopeJoint
    EXTERN_DLL_EXPORT void RopeJointGetLocalAnchorA( IntPtr j, Vector2 * localAnchorA )
    {
        if( j == NULL )
            return;
        
        b2RopeJoint *joint = (b2RopeJoint*)j;
        *localAnchorA = joint->GetLocalAnchorA();
    }
    
    EXTERN_DLL_EXPORT void RopeJointGetLocalAnchorB( IntPtr j, Vector2 * localAnchorB )
    {
        if( j == NULL )
            return;
        
        b2RopeJoint *joint = (b2RopeJoint*)j;
        *localAnchorB = joint->GetLocalAnchorB();
    }
    
    EXTERN_DLL_EXPORT void RopeJointSetMaxLength( IntPtr j, float maxLength )
    {
        if( j == NULL )
            return;
        
        b2RopeJoint *joint = (b2RopeJoint*)j;
        joint->SetMaxLength(maxLength);
    }
    
    EXTERN_DLL_EXPORT float RopeJointGetMaxLength( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2RopeJoint *joint = (b2RopeJoint*)j;
        return joint->GetMaxLength();
    }
    
    EXTERN_DLL_EXPORT int RopeJointGetLimitState( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2RopeJoint *joint = (b2RopeJoint*)j;
        return joint->GetLimitState();
    }
}