#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"

//DistanceJoint
EXTERN_DLL_EXPORT void DistanceJointGetLocalAnchorA( IntPtr j, Vector2 * anchorA )
{
    if( j == NULL )
        return;
    
    b2DistanceJoint *joint = (b2DistanceJoint*)j;
    *anchorA = joint->GetLocalAnchorA();
}

EXTERN_DLL_EXPORT void DistanceJointGetLocalAnchorB( IntPtr j, Vector2 * anchorB )
{
    if( j == NULL )
        return;
    
    b2DistanceJoint *joint = (b2DistanceJoint*)j;
    *anchorB = joint->GetLocalAnchorB();
}

EXTERN_DLL_EXPORT void DistanceJointSetLength( IntPtr j, float32 length)
{
    if( j == NULL )
        return;
    
    b2DistanceJoint *joint = (b2DistanceJoint*)j;
    joint->SetLength(length);
}

EXTERN_DLL_EXPORT float32 DistanceJointGetLength( IntPtr j )
{
    if( j == NULL )
        return 0;
    
    b2DistanceJoint *joint = (b2DistanceJoint*)j;
    return joint->GetLength();
}

EXTERN_DLL_EXPORT void DistanceJointSetFrequency( IntPtr j , float32 hz)
{
    if( j == NULL )
        return;
    
    b2DistanceJoint *joint = (b2DistanceJoint*)j;
    joint->SetFrequency(hz);
}

EXTERN_DLL_EXPORT float32 DistanceJointGetFrequency( IntPtr j )
{
    if( j == NULL )
        return 0;
    
    b2DistanceJoint *joint = (b2DistanceJoint*)j;
    return joint->GetFrequency();
}

EXTERN_DLL_EXPORT void DistanceJointSetDampingRatio( IntPtr j, float32 ratio)
{
    if( j == NULL )
        return;
    
    b2DistanceJoint *joint = (b2DistanceJoint*)j;
    joint->SetDampingRatio(ratio);
}

EXTERN_DLL_EXPORT float32 DistanceJointGetDampingRatio( IntPtr j )
{
    if( j == NULL )
        return 0;
    
    b2DistanceJoint *joint = (b2DistanceJoint*)j;
    return joint->GetDampingRatio();
}
