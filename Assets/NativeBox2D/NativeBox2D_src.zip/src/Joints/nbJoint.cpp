#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"

extern "C"
{
    //Joint
    EXTERN_DLL_EXPORT int JointGetType( IntPtr j )
    {
        if( j == NULL )
            return false;
        
        b2Joint *joint = (b2Joint*)j;
        return joint->GetType();
    }
    
    EXTERN_DLL_EXPORT IntPtr JointGetBodyA( IntPtr j )
    {
        if( j == NULL )
            return NULL;
        
        b2Joint *joint = (b2Joint*)j;
        return joint->GetBodyA();
    }
    
    EXTERN_DLL_EXPORT IntPtr JointGetBodyB( IntPtr j )
    {
        if( j == NULL )
            return NULL;
        
        b2Joint *joint = (b2Joint*)j;
        return joint->GetBodyB();
    }
    
    EXTERN_DLL_EXPORT void JointGetAnchorA( IntPtr j, Vector2 * anchorA )
    {
        if( j == NULL )
            return;
        
        b2Joint *joint = (b2Joint*)j;
        *anchorA = joint->GetAnchorA();
    }
    
    EXTERN_DLL_EXPORT void JointGetAnchorB( IntPtr j, Vector2 * anchorB )
    {
        if( j == NULL )
            return;
        
        b2Joint *joint = (b2Joint*)j;
        *anchorB = joint->GetAnchorB();
    }
    
    EXTERN_DLL_EXPORT void JointGetReactionForce( IntPtr j, float32 inv_dt, Vector2 * force )
    {
        if( j == NULL )
            return;
        
        b2Joint *joint = (b2Joint*)j;
        *force = joint->GetReactionForce(inv_dt);
    }
    
    EXTERN_DLL_EXPORT float JointGetReactionTorque( IntPtr j, float32 inv_dt  )
    {
        if( j == NULL )
            return 0;
        
        b2Joint *joint = (b2Joint*)j;
        return joint->GetReactionTorque(inv_dt);
    }
    
    EXTERN_DLL_EXPORT bool JointIsActive( IntPtr j )
    {
        if( j == NULL )
            return false;
        
        b2Joint *joint = (b2Joint*)j;
        return joint->IsActive();
    }
    
    EXTERN_DLL_EXPORT bool JointGetCollideConnected( IntPtr j )
    {
        if( j == NULL )
            return false;
        
        b2Joint *joint = (b2Joint*)j;
        return joint->GetCollideConnected();
    }
}