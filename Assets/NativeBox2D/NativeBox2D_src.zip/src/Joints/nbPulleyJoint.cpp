#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"

extern "C"
{
    //PulleyJoint
    EXTERN_DLL_EXPORT void PulleyJointGetGroundAnchorA( IntPtr j, Vector2 * groundAnchorA )
    {
        if( j == NULL )
            return;
        
        b2PulleyJoint *joint = (b2PulleyJoint*)j;
        *groundAnchorA = joint->GetGroundAnchorA();
    }
    
    EXTERN_DLL_EXPORT void PulleyJointGetGroundAnchorB( IntPtr j, Vector2 * groundAnchorB )
    {
        if( j == NULL )
            return;
        
        b2PulleyJoint *joint = (b2PulleyJoint*)j;
        *groundAnchorB = joint->GetGroundAnchorB();
    }
    
    EXTERN_DLL_EXPORT float PulleyJointGetLengthA( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2PulleyJoint *joint = (b2PulleyJoint*)j;
        return joint->GetLengthA();
    }
     
    EXTERN_DLL_EXPORT float PulleyJointGetLengthB( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2PulleyJoint *joint = (b2PulleyJoint*)j;
        return joint->GetLengthB();
    }
    
    EXTERN_DLL_EXPORT float PulleyJointGetRatio( IntPtr j )
    {
        if( j == NULL )
            return 0;

        b2PulleyJoint *joint = (b2PulleyJoint*)j;
        return joint->GetRatio();
    }
}