#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"

extern "C"
{
    //GearJoint
	EXTERN_DLL_EXPORT IntPtr GearJointGetJoint1( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2GearJoint *joint = (b2GearJoint*)j;
        return joint->GetJoint1();
    }
    
	EXTERN_DLL_EXPORT IntPtr GearJointGetJoint2( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2GearJoint *joint = (b2GearJoint*)j;
        return joint->GetJoint2();
    }
    
	EXTERN_DLL_EXPORT void GearJointSetRatio( IntPtr j , float32 ratio)
    {
        if( j == NULL )
            return;
        
        b2GearJoint *joint = (b2GearJoint*)j;
        return joint->SetRatio(ratio);
    }
    
	EXTERN_DLL_EXPORT float32 GearJointGetRatio( IntPtr j )
    {
        if( j == NULL )
            return 0;
        
        b2GearJoint *joint = (b2GearJoint*)j;
        return joint->GetRatio();
    }
}