#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"

//FrictionJoint
EXTERN_DLL_EXPORT void FrictionJointGetLocalAnchorA( IntPtr j, Vector2 * anchorA )
{
    if( j == NULL )
        return;
    
    b2FrictionJoint *joint = (b2FrictionJoint*)j;
    *anchorA = joint->GetLocalAnchorA();
}

EXTERN_DLL_EXPORT void FrictionJointGetLocalAnchorB( IntPtr j, Vector2 * anchorB )
{
    if( j == NULL )
        return;
    
    b2FrictionJoint *joint = (b2FrictionJoint*)j;
    *anchorB = joint->GetLocalAnchorB();
}

EXTERN_DLL_EXPORT void FrictionJointSetMaxForce( IntPtr j , float32 force)
{
    if( j == NULL )
        return;
    
    b2FrictionJoint *joint = (b2FrictionJoint*)j;
    joint->SetMaxForce(force);
}

EXTERN_DLL_EXPORT float32 FrictionJointGetMaxForce( IntPtr j )
{
    if( j == NULL )
        return 0;
    
    b2FrictionJoint *joint = (b2FrictionJoint*)j;
    return joint->GetMaxForce();
}

EXTERN_DLL_EXPORT void FrictionJointSetMaxTorque( IntPtr j , float32 torque)
{
    if( j == NULL )
        return;
    
    b2FrictionJoint *joint = (b2FrictionJoint*)j;
    joint->SetMaxTorque(torque);
}

EXTERN_DLL_EXPORT float32 FrictionJointGetMaxTorque( IntPtr j )
{
    if( j == NULL )
        return 0;
    
    b2FrictionJoint *joint = (b2FrictionJoint*)j;
    return joint->GetMaxTorque();
}
