#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"


EXTERN_DLL_EXPORT void SetSensor( IntPtr s, bool sensor)
{
    if( s == NULL )
        return;
    
    b2Fixture *f = (b2Fixture*)s;
    f->SetSensor(sensor);
}

EXTERN_DLL_EXPORT bool IsSensor( IntPtr s )
{
    if( s == NULL )
        return false;
    
    b2Fixture *f = (b2Fixture*)s;
    return f->IsSensor();
}

EXTERN_DLL_EXPORT void SetFilterData( IntPtr s, int categoryBits, int maskBits, int groupIndex)
{
    if( s == NULL )
        return;
    
    b2Fixture *f = (b2Fixture*)s;
    b2Filter fil;
    fil.categoryBits = categoryBits;
    fil.maskBits = maskBits;
    fil.groupIndex = groupIndex;
    f->SetFilterData(fil);
}

EXTERN_DLL_EXPORT void GetFilterData( IntPtr s, int* categoryBits, int* maskBits, int* groupIndex )
{
    if( s == NULL )
        return;
    
    b2Fixture *f = (b2Fixture*)s;
    b2Filter fil = f->GetFilterData();
    *categoryBits = fil.categoryBits;
    *maskBits = fil.maskBits;
    *groupIndex = fil.groupIndex;
}

EXTERN_DLL_EXPORT void Refilter( IntPtr s )
{
    if( s == NULL )
        return;
    
    b2Fixture *f = (b2Fixture*)s;
    f->Refilter();
}

EXTERN_DLL_EXPORT IntPtr GetBody( IntPtr s )
{
    if( s == NULL )
        return NULL;
    
    b2Fixture *f = (b2Fixture*)s;
    return f->GetBody();
}
    
EXTERN_DLL_EXPORT bool TestPoint( IntPtr s, Vector2 p)
{
    if( s == NULL )
        return false;
    
    b2Fixture *f = (b2Fixture*)s;
    return f->TestPoint(p);
}

EXTERN_DLL_EXPORT bool RayCastShape( IntPtr s, int32 childIndex, Vector2 p1, Vector2 p2, float maxFraction,
             Vector2* normal, float* fraction)
{
    if( s == NULL )
        return false;
    
    b2Fixture *f = (b2Fixture*)s;
    b2RayCastInput input;
    b2RayCastOutput output;
    input.p1 = p1;
    input.p2 = p2;
    input.maxFraction = maxFraction;
    bool ret = f->RayCast(&output, input, childIndex);
    *normal = output.normal;
    *fraction = output.fraction;
    
    return ret;
}

EXTERN_DLL_EXPORT void SetDensity( IntPtr s, float32 density)
{
    if( s == NULL )
        return;
    
    b2Fixture *f = (b2Fixture*)s;
    f->SetDensity(density);
}

EXTERN_DLL_EXPORT float32 GetDensity( IntPtr s )
{
    if( s == NULL )
        return 0;
    
    b2Fixture *f = (b2Fixture*)s;
    return f->GetDensity();
}

EXTERN_DLL_EXPORT float32 GetFriction( IntPtr s )
{
    if( s == NULL )
        return 0;
    
    b2Fixture *f = (b2Fixture*)s;
    return f->GetFriction();
}

EXTERN_DLL_EXPORT void SetFriction( IntPtr s, float32 friction)
{
    if( s == NULL )
        return;
    
    b2Fixture *f = (b2Fixture*)s;
    f->SetFriction(friction);
}

EXTERN_DLL_EXPORT float32 GetRestitution( IntPtr s )
{
    if( s == NULL )
        return 0;
    
    b2Fixture *f = (b2Fixture*)s;
    return f->GetRestitution();
}

EXTERN_DLL_EXPORT void SetRestitution( IntPtr s, float32 restitution)
{
    if( s == NULL )
        return;
    
    b2Fixture *f = (b2Fixture*)s;
    f->SetRestitution(restitution);
}

EXTERN_DLL_EXPORT void GetAABB( IntPtr s, int32 childIndex, Vector2* lowerBound, Vector2* upperBound)
{
    if( s == NULL )
        return;
    
    b2Fixture *f = (b2Fixture*)s;
    b2AABB aabb = f->GetAABB(childIndex);
    *lowerBound = aabb.lowerBound;
    *upperBound = aabb.upperBound;
}
