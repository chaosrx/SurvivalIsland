#include <Box2d/Box2d.h>
#include <cstdio>
#include "utils.h"
#include "Render.h"

#define DEBUGDRAW 1
   
GL_BEGIN GL_Begin = NULL;
GL_END GL_End = NULL;
GL_VERTEX3 GL_Vertex3 = NULL;
GL_COLOR4 GL_Color4 = NULL;
GL_DRAWSTRING GL_DrawString = NULL;


class QueryCallback : public b2QueryCallback
{
public:

    QueryCallback( QUERYCALLBACK cb )
    {
        _cb = cb;
    }
    
	bool ReportFixture(b2Fixture* fixture)
	{
		b2Body* body = fixture->GetBody();
        return _cb( body );
	}
    
    QUERYCALLBACK _cb;
};

class RaycastCallback : public b2RayCastCallback
{
public:
    
    RaycastCallback( RAYCASTCALLBACK cb )
    {
        _cb = cb;
    }
    
	float ReportFixture(b2Fixture* fixture, const b2Vec2& point,
                        const b2Vec2& normal, float32 fraction)
	{
		b2Body* body = fixture->GetBody();
        return _cb( body, point, normal, fraction );
	}
    
    RAYCASTCALLBACK _cb;
};

class ContactCallback : public b2ContactListener
{
public:
    
    void BeginContact(b2Contact* contact)
    {
        if( _begincb )
            _begincb(contact);
    }
    
    void EndContact(b2Contact* contact)
    {
        if( _endcb )
            _endcb(contact);
    }
    
    CONTACTCALLBACK _begincb;
    CONTACTCALLBACK _endcb;
};

class DestructionListener : public b2DestructionListener
{
public:
    
    void SayGoodbye(b2Joint* joint)
    {
        if( _jcb )
            _jcb( joint );
    }
    
    void SayGoodbye(b2Fixture* fixture)
    {
        if( _fcb )
            _fcb( fixture );
    }
    
    DESTRCTIONCALLBACK _jcb;
    DESTRCTIONCALLBACK _fcb;
};

class ContactFilter : public b2ContactFilter
{
public:
    
    bool ShouldCollide(b2Fixture* fixtureA, b2Fixture* fixtureB)
    {
        if( _cb )
            return _cb(fixtureA, fixtureB);
        else
            return true;
    }
    
    SHOULDCOLLIDECALLBACK _cb;
};

struct DistanceJointDef
{
	b2Body* bodyA;
	b2Body* bodyB;
	bool collideConnected;
	
	Vector2 localAnchorA;
	Vector2 localAnchorB;
	float length;
	float frequencyHz;
	float dampingRatio;
};

struct FrictionJointDef
{
	b2Body* bodyA;
	b2Body* bodyB;
	bool collideConnected;
	Vector2 localAnchorA;
	Vector2 localAnchorB;
	float maxForce;
	float maxTorque;
};

struct GearJointDef
{
	b2Body* bodyA;
	b2Body* bodyB;
	bool collideConnected;
	
	b2Joint* joint1;
    b2Joint* joint2;
    float ratio;
};

struct MouseJointDef
{
	b2Body* bodyA;
	b2Body* bodyB;
	bool collideConnected;
	
    Vector2 target;
	float maxForce;
	float frequencyHz;
	float dampingRatio;
};

struct PrismaticJointDef
{
	b2Body* bodyA;
	b2Body* bodyB;
	bool collideConnected;
	Vector2 localAnchorA;
	Vector2 localAnchorB;
    Vector2 localAxisA;
	float referenceAngle;
	bool enableLimit;
	float lowerTranslation;
	float upperTranslation;
	bool enableMotor;
	float maxMotorForce;
    float motorSpeed;
};

struct PulleyJointDef
{
	b2Body* bodyA;
	b2Body* bodyB;
	bool collideConnected;
    
	Vector2 groundAnchorA;
	Vector2 groundAnchorB;
	Vector2 localAnchorA;
	Vector2 localAnchorB;
	float lengthA;
	float lengthB;
	float ratio;
};

struct RevoluteJointDef
{
	b2Body* bodyA;
	b2Body* bodyB;
	bool collideConnected;
	Vector2 localAnchorA;
	Vector2 localAnchorB;
	float referenceAngle;
	bool enableLimit;
	float lowerAngle;
	float upperAngle;
	bool enableMotor;
	float motorSpeed;
	float maxMotorTorque;
};

struct RopeJointDef
{
	b2Body* bodyA;
	b2Body* bodyB;
	bool collideConnected;
	Vector2 localAnchorA;
	Vector2 localAnchorB;
    float   maxLength;
};

struct WeldJointDef
{
	b2Body* bodyA;
	b2Body* bodyB;
	bool collideConnected;
	Vector2 localAnchorA;
	Vector2 localAnchorB;
    float   referenceAngle;
    float frequencyHz;
	float dampingRatio;
};

struct WheelJointDef
{
	b2Body* bodyA;
	b2Body* bodyB;
	bool collideConnected;
	Vector2 localAnchorA;
	Vector2 localAnchorB;
	Vector2 localAxisA;
	bool enableMotor;
	float maxMotorTorque;
	float motorSpeed;
	float frequencyHz;
	float dampingRatio;
};

static DebugDraw dd;
static ContactCallback ccb;
static DestructionListener dl;
static ContactFilter cf;
 
EXTERN_DLL_EXPORT void SetBebugDrawCallbacks( GL_BEGIN begin, GL_END end, GL_VERTEX3 vertex, GL_COLOR4 color, GL_DRAWSTRING ds )
{
    GL_Begin = begin;
    GL_End = end;
    GL_Vertex3 = vertex;
    GL_Color4 = color;
    GL_DrawString = ds;
    GL_Begin(1);
    GL_End();
}
    
EXTERN_DLL_EXPORT void SetDebugDrawFlags( int flag )
{
    dd.SetFlags(flag);
}
    
EXTERN_DLL_EXPORT IntPtr CreateWorld(b2Vec2 gravity)
{
    b2World *world = new b2World( gravity );
    world->SetDebugDraw(&dd);
    return world;
}

EXTERN_DLL_EXPORT void DestroyWorld( IntPtr w )
{
    if( w == NULL )
        return;
    
    b2World* world = (b2World*)w;        
    delete world;
}

EXTERN_DLL_EXPORT void SetDestructionListener( IntPtr w, DESTRCTIONCALLBACK jointDestrction, DESTRCTIONCALLBACK fixtureDestruction  )
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    
    dl._jcb = jointDestrction;
    dl._fcb = fixtureDestruction;
    world->SetDestructionListener(&dl);
}

EXTERN_DLL_EXPORT void SetContactFilter( IntPtr w, SHOULDCOLLIDECALLBACK shouldCollide )
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    
    cf._cb = shouldCollide;
    world->SetContactFilter(&cf);
}

EXTERN_DLL_EXPORT void SetContactListener( IntPtr w, CONTACTCALLBACK begincb, CONTACTCALLBACK endcb  )
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    
    ccb._begincb = begincb;
    ccb._endcb = endcb;
    world->SetContactListener(&ccb);
}

EXTERN_DLL_EXPORT IntPtr CreateBody( IntPtr w, b2BodyDef bd)
{
    if( w == NULL )
        return NULL;
    b2World* world = (b2World*)w;
    
    return world->CreateBody(&bd);
}

EXTERN_DLL_EXPORT void DestroyBody( IntPtr w, IntPtr b )
{
    if( w == NULL || b == NULL )
        return;
    
    b2World* world = (b2World*)w;
    world->DestroyBody((b2Body*)b);
}

EXTERN_DLL_EXPORT IntPtr CreateDistanceJoint( IntPtr w ,  DistanceJointDef def )
{
    if( w == NULL )
        return NULL;
    b2World *world = (b2World*)w;
    
    b2DistanceJointDef jd;
    jd.bodyA = def.bodyA;
    jd.bodyB = def.bodyB;
    jd.localAnchorA = def.localAnchorA;
    jd.localAnchorB = def.localAnchorB;
    jd.length = def.length;
    jd.frequencyHz = def.frequencyHz;
    jd.dampingRatio = def.dampingRatio;
    return world->CreateJoint(&jd);
}

EXTERN_DLL_EXPORT IntPtr CreateFrictionJoint( IntPtr w ,  FrictionJointDef def)
{
    if( w == NULL )
        return NULL;
    b2World *world = (b2World*)w;
    
    b2FrictionJointDef jd;
    jd.bodyA = def.bodyA;
    jd.bodyB = def.bodyB;
    jd.collideConnected = def.collideConnected;
    jd.localAnchorA = def.localAnchorA;
    jd.localAnchorB = def.localAnchorB;
    jd.maxForce = def.maxForce;
    jd.maxTorque = def.maxTorque;
    return world->CreateJoint(&jd);
}

EXTERN_DLL_EXPORT IntPtr CreateGearJoint( IntPtr w ,  GearJointDef def )
{
    if( w == NULL )
        return NULL;
    b2World *world = (b2World*)w;
    
    b2GearJointDef jd;
    jd.bodyA = def.bodyA;
    jd.bodyB = def.bodyB;
    jd.joint1 = def.joint1;
    jd.joint2 = def.joint2;
    jd.ratio = def.ratio;
    return world->CreateJoint(&jd);
}

EXTERN_DLL_EXPORT IntPtr CreateMouseJoint( IntPtr w ,  MouseJointDef def )
{
    if( w == NULL )
        return NULL;
    b2World *world = (b2World*)w;
    
    b2MouseJointDef jd;
    jd.bodyA = def.bodyA;
    jd.bodyB = def.bodyB;
    jd.collideConnected = def.collideConnected;
    jd.target = def.target;
    jd.maxForce = def.maxForce;
    jd.frequencyHz = def.frequencyHz;
    jd.dampingRatio = def.dampingRatio;
    
    return world->CreateJoint(&jd);
}

EXTERN_DLL_EXPORT IntPtr CreatePrismaticJoint( IntPtr w ,  PrismaticJointDef def )
{
    if( w == NULL )
        return NULL;
    b2World *world = (b2World*)w;
    
    b2PrismaticJointDef jd;
    jd.bodyA = def.bodyA;
    jd.bodyB = def.bodyB;
    jd.localAnchorA = def.localAnchorA;
    jd.localAnchorB = def.localAnchorB;
    jd.localAxisA = def.localAxisA;
    jd.referenceAngle = def.referenceAngle;
    jd.enableLimit = def.enableLimit;
    jd.lowerTranslation = def.lowerTranslation;
    jd.upperTranslation = def.upperTranslation;
    jd.enableMotor = def.enableMotor;
    jd.maxMotorForce = def.maxMotorForce;
    jd.motorSpeed = def.motorSpeed;
    return world->CreateJoint(&jd);
}

EXTERN_DLL_EXPORT IntPtr CreatePulleyJoint( IntPtr w ,  PulleyJointDef def )
{
    if( w == NULL )
        return NULL;
    b2World *world = (b2World*)w;
    
    b2PulleyJointDef jd;
    jd.bodyA = def.bodyA;
    jd.bodyB = def.bodyB;
    jd.groundAnchorA = def.groundAnchorA;
    jd.groundAnchorB = def.groundAnchorB;
    jd.localAnchorA = def.localAnchorA;
    jd.localAnchorB = def.localAnchorB;
    jd.lengthA = def.lengthA;
    jd.lengthB = def.lengthB;
    jd.ratio = def.ratio;
    return world->CreateJoint(&jd);
}

EXTERN_DLL_EXPORT IntPtr  CreateRevoluteJoint( IntPtr w ,  RevoluteJointDef def )
{
    if( w == NULL )
        return NULL;
    b2World *world = (b2World*)w;
    
    b2RevoluteJointDef jd;
    jd.bodyA = def.bodyA;
    jd.bodyB = def.bodyB;
    jd.collideConnected = def.collideConnected;
    jd.localAnchorA = def.localAnchorA;
    jd.localAnchorB = def.localAnchorB;
    jd.referenceAngle = def.referenceAngle;
    jd.enableLimit = def.enableLimit;
    jd.lowerAngle = def.lowerAngle;
    jd.upperAngle = def.upperAngle;
    jd.enableMotor = def.enableMotor;
    jd.motorSpeed = def.motorSpeed;
    jd.maxMotorTorque = def.maxMotorTorque;
    return world->CreateJoint(&jd);
}

EXTERN_DLL_EXPORT IntPtr  CreateRopeJoint( IntPtr w ,  RopeJointDef def )
{
    if( w == NULL )
        return NULL;
    b2World *world = (b2World*)w;
    
    b2RopeJointDef jd;
    jd.bodyA = def.bodyA;
    jd.bodyB = def.bodyB;
    jd.localAnchorA = def.localAnchorA;
    jd.localAnchorB = def.localAnchorB;
    jd.maxLength = def.maxLength;
    return world->CreateJoint(&jd);
}

EXTERN_DLL_EXPORT IntPtr CreateWeldJoint( IntPtr w ,  WeldJointDef def )
{
    if( w == NULL )
        return NULL;
    b2World *world = (b2World*)w;
    
    b2WeldJointDef jd;
    jd.bodyA = def.bodyA;
    jd.bodyB = def.bodyB;
    jd.localAnchorA = def.localAnchorA;
    jd.localAnchorB = def.localAnchorB;
    jd.referenceAngle = def.referenceAngle;
    jd.frequencyHz = def.frequencyHz;
    jd.dampingRatio = def.dampingRatio;
    return world->CreateJoint(&jd);
}

EXTERN_DLL_EXPORT IntPtr CreateWheelJoint( IntPtr w , WheelJointDef def )
{
    if( w == NULL )
        return NULL;
    b2World *world = (b2World*)w;

    b2WheelJointDef jd;
    jd.bodyA = def.bodyA;
    jd.bodyB = def.bodyB;
    jd.collideConnected = def.collideConnected;
    jd.localAnchorA = def.localAnchorA;
    jd.localAnchorB = def.localAnchorB;
    jd.localAxisA = def.localAxisA;
    jd.enableMotor = def.enableMotor;
    jd.maxMotorTorque = def.maxMotorTorque;
    jd.motorSpeed = def.motorSpeed;
    jd.frequencyHz = def.frequencyHz;
    jd.dampingRatio = def.dampingRatio;
    return world->CreateJoint(&jd);
}

EXTERN_DLL_EXPORT void DestroyJoint( IntPtr w	, IntPtr  j )
{
    if( w == NULL || j == NULL )
        return;
    
    b2World *world = (b2World*)w;
   
    b2Joint* joint = (b2Joint*)j;
    world->DestroyJoint(joint);
}

EXTERN_DLL_EXPORT void Step( IntPtr w	, float32 timeStep, int32 velocityIterations, int32 positionIterations)
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    world->Step(timeStep, velocityIterations, positionIterations);
}


EXTERN_DLL_EXPORT void ClearForces( IntPtr w )
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    world->ClearForces();
}

EXTERN_DLL_EXPORT void DrawDebugData( IntPtr w )
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    world->DrawDebugData();
}

EXTERN_DLL_EXPORT void QueryAABB( IntPtr w, Vector2 lowerBound, Vector2 upperBound, QUERYCALLBACK cb )
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    
    b2AABB aabb;
    aabb.lowerBound = lowerBound;
    aabb.upperBound = upperBound;
    QueryCallback _cb( cb );
    world->QueryAABB(&_cb, aabb );
}

EXTERN_DLL_EXPORT void RayCast( IntPtr w, Vector2 point1, Vector2 point2, RAYCASTCALLBACK cb)
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    RaycastCallback _cb(cb);
    world->RayCast( &_cb, point1, point2);
}

EXTERN_DLL_EXPORT void SetAllowSleeping( IntPtr w, bool flag)
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    world->SetAllowSleeping(flag);
}

EXTERN_DLL_EXPORT bool GetAllowSleeping( IntPtr w )
{
    if( w == NULL )
        return false;
    b2World *world = (b2World*)w;
    return world->GetAllowSleeping();
}

EXTERN_DLL_EXPORT void SetWarmStarting( IntPtr w ,bool flag)
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    world->SetWarmStarting(flag);
}

EXTERN_DLL_EXPORT bool GetWarmStarting( IntPtr w )
{
    if( w == NULL )
        return false;
    b2World *world = (b2World*)w;
    return world->GetWarmStarting();
}

EXTERN_DLL_EXPORT void SetContinuousPhysics( IntPtr w ,bool flag)
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    world->SetContinuousPhysics(flag);
}

EXTERN_DLL_EXPORT bool GetContinuousPhysics( IntPtr w )
{
    if( w == NULL )
        return false;
    b2World *world = (b2World*)w;
    return world->GetContinuousPhysics();
}

EXTERN_DLL_EXPORT void SetSubStepping( IntPtr w ,bool flag)
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    world->SetSubStepping(flag);
}

EXTERN_DLL_EXPORT bool GetSubStepping( IntPtr w )
{
    if( w == NULL )
        return false;
    b2World *world = (b2World*)w;
    return world->GetSubStepping();
}

EXTERN_DLL_EXPORT int32 GetProxyCount( IntPtr w )
{
    if( w == NULL )
        return 0;
    b2World *world = (b2World*)w;
    return world->GetProxyCount();
}

EXTERN_DLL_EXPORT int32 GetBodyCount( IntPtr w )
{
    if( w == NULL )
        return 0;
    b2World *world = (b2World*)w;
    return world->GetBodyCount();
}

EXTERN_DLL_EXPORT int32 GetJointCount( IntPtr w )
{
    if( w == NULL )
        return 0;
    b2World *world = (b2World*)w;
    return world->GetJointCount();
}

EXTERN_DLL_EXPORT int32 GetContactCount( IntPtr w )
{
    if( w == NULL )
        return 0;
    b2World *world = (b2World*)w;
    return world->GetContactCount();
}


EXTERN_DLL_EXPORT int32 GetTreeHeight( IntPtr w )
{
    if( w == NULL )
        return 0;
    b2World *world = (b2World*)w;
    return world->GetTreeHeight();
}

EXTERN_DLL_EXPORT int32 GetTreeBalance( IntPtr w )
{
    if( w == NULL )
        return 0;
    b2World *world = (b2World*)w;
    return world->GetTreeBalance();
}

EXTERN_DLL_EXPORT float32 GetTreeQuality( IntPtr w )
{
    if( w == NULL )
        return 0;
    b2World *world = (b2World*)w;
    return world->GetTreeQuality();
}

EXTERN_DLL_EXPORT void SetGravity( IntPtr w , Vector2 gravity)
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    world->SetGravity(gravity);
}

EXTERN_DLL_EXPORT void GetGravity( IntPtr w, Vector2 *gravity )
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    *gravity = world->GetGravity();
}

EXTERN_DLL_EXPORT bool IsLocked( IntPtr w )
{
    if( w == NULL )
        return false;
    b2World *world = (b2World*)w;
    return world->IsLocked();
}

EXTERN_DLL_EXPORT void SetAutoClearForces( IntPtr w , bool flag)
{
    if( w == NULL )
        return;
    b2World *world = (b2World*)w;
    world->SetAutoClearForces(flag);
}

EXTERN_DLL_EXPORT bool GetAutoClearForces( IntPtr w )
{
    if( w == NULL )
        return false;
    b2World *world = (b2World*)w;
    return world->GetAutoClearForces();
}