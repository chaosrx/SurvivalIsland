/*
* Copyright (c) 2006-2007 Erin Catto http://www.box2d.org
*
* This software is provided 'as-is', without any express or implied
* warranty.  In no event will the authors be held liable for any damages
* arising from the use of this software.
* Permission is granted to anyone to use this software for any purpose,
* including commercial applications, and to alter it and redistribute it
* freely, subject to the following restrictions:
* 1. The origin of this software must not be misrepresented; you must not
* claim that you wrote the original software. If you use this software
* in a product, an acknowledgment in the product documentation would be
* appreciated but is not required.
* 2. Altered source versions must be plainly marked as such, and must not be
* misrepresented as being the original software.
* 3. This notice may not be removed or altered from any source distribution.
*/

#ifndef UTILS_H
#define UTILS_H

#ifdef _WIN32
#define EXTERN_DLL_EXPORT extern "C" __declspec(dllexport) 
#else
#define EXTERN_DLL_EXPORT extern "C"
#define __stdcall 
#endif

typedef void* MonoArray;
enum { kMonoArrayOffset = 0};

/*return the i element of the array*/
template<class T>
T& GetMonoArrayElement (MonoArray* array, int i) {
	char* raw = kMonoArrayOffset + i * sizeof (T) + (char*)array;
	return *(T*)raw;
}

/*insert elem in the position i of the array*/
template<class T>
void SetMonoArrayElement (MonoArray* array, int i, T elem) {
	char* raw = kMonoArrayOffset + i * sizeof(T) + (char*)array;
	*(T*)raw = elem;
}

/* BeginMode */
#define GL_POINTS                         0x0000
#define GL_LINES                          0x0001
#define GL_LINE_LOOP                      0x0002
#define GL_LINE_STRIP                     0x0003
#define GL_TRIANGLES                      0x0004
#define GL_TRIANGLE_STRIP                 0x0005
#define GL_TRIANGLE_FAN                   0x0006
#define GL_QUADS                          0x0007
#define GL_QUAD_STRIP                     0x0008
#define GL_POLYGON                        0x0009
#define RADTODEG                          57.2957787f
#define CHECKWORLD(r)                     do { if( gWorld == NULL ) return r; } while(0);

typedef void* IntPtr;
typedef b2Vec2 Vector2;

typedef void (__stdcall *GL_VERTEX3)(float x, float y, float z);
typedef void (__stdcall *GL_BEGIN)(int mode);
typedef void (__stdcall *GL_END)();
typedef void (__stdcall *GL_COLOR4)(float r, float g, float b, float a);
typedef void (__stdcall *GL_DRAWSTRING)(float x, float y, char * str);
typedef bool (__stdcall *QUERYCALLBACK)( IntPtr b );
typedef bool (__stdcall *RAYCASTCALLBACK)( IntPtr b, Vector2 point, Vector2 normal, float fraction );
typedef void (__stdcall *CONTACTCALLBACK)( IntPtr contact );
typedef bool (__stdcall *SHOULDCOLLIDECALLBACK)( IntPtr f1, IntPtr f2 );
typedef void (__stdcall *DESTRCTIONCALLBACK)( IntPtr d );
#endif
